def Is_popular(product):
    if product.year<2017 and product.price < 3000:
        return True
    else:
        return False

