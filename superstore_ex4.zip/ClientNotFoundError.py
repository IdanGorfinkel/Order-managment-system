class ClientNotFoundError(Exception) :
    pass