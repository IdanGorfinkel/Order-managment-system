class PressBerror(Exception):
    pass

