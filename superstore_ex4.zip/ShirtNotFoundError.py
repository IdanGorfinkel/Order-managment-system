class ShirtNotFoundError(Exception):
    pass

