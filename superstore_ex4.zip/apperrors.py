class IDerror(Exception):
    pass

class ProductnNotFind(Exception):
    pass

class PriceNotInt(Exception):
    pass

class HardDiskNum(Exception):
    pass

class ScreenNum(Exception):
    pass

class ResError(Exception):
    pass

class CoreError(Exception):
    pass

class EmptyEntry(Exception):
    pass